public class UncertainRealNumber implements UncertainReal,Cloneable {
	protected double x =0.0; 
	protected double u = 0.0;

    /**
     * Constructors 
     */
    public UncertainRealNumber () {
        this.x = 0.0; this.u = 0.0;
    }

	public UncertainRealNumber(double x){ //"promotes" a real x to (x,0) 
		this.x = x; this.u = 0.0;
	}
  
    public UncertainRealNumber (double x, double u) {
        this.x = x; this.u = u;
    }
	
    public UncertainRealNumber(String x) { //creates an UncertainReal from a string representing a real, with u=0.
    	this.x = Double.parseDouble(x);
    	this.u = 0.0;
    }
    public UncertainRealNumber(String x, String u) { //creates an UncertainReal from two strings representing (x,u).
    	this.x = Double.parseDouble(x);
    	this.u = Double.parseDouble(u);
    }
   
    /**
     * Setters and getters 
     */
    public double getX() {
		return x; 
	}
    public void setX(double x) {
		this.x = x; 
	}
    public double getU() {
		return u;
	}
	public void setU(double u) {
		this.u = u;
	}

   /*********
     * 
     * Type Operations
     */

	@Override
	public UncertainReal add(UncertainReal r) {
		UncertainRealNumber result = new UncertainRealNumber();
		result.setX(this.getX() + r.getX());
		result.setU( Math.sqrt((this.getU() * this.getU()) + (r.getU() * r.getU()) ));
		return result;
	}
	
	@Override
	public UncertainReal minus(UncertainReal r) {
		UncertainRealNumber result = new UncertainRealNumber();
			result.setX(this.getX() - r.getX());
			result.setU(Math.sqrt((this.getU()*this.getU()) + (r.getU()*r.getU())));
			return result;
	}

	@Override
	public UncertainReal mult(UncertainReal r) {
		UncertainRealNumber result = new UncertainRealNumber();
		
		result.setX(this.getX() * r.getX());
		
		double a = r.getX()*r.getX()*this.getU()*this.getU();
		double b = this.getX()*this.getX()*r.getU()*r.getU();
		result.setU(Math.sqrt(a + b));
	
		return result;
	}
	
	@Override
	public UncertainReal divide(UncertainReal r) {
		UncertainRealNumber result = new UncertainRealNumber();
	
		double a = this.getX() / r.getX();
		double b = (this.getX()*r.getU()*r.getU())/(Math.pow(r.getX(), 3));
		result.setX(a + b);
		
		double c = ((u*u)/r.getX());
		double d = (this.getX()*this.getX()*r.getU()*r.getU()) / Math.pow(r.getX(), 4);
		result.setU(Math.sqrt(c + d));
		
		return result;
	}
		
	@Override
	public UncertainReal abs() {
		UncertainRealNumber result = new UncertainRealNumber();
	
		result.setX(Math.abs(this.getX()));
		result.setU(this.getU());
	
		return result;
	}
	
	@Override
	public UncertainReal neg() {
		UncertainRealNumber result = new UncertainRealNumber();
		
		result.setX(-this.getX());
		result.setU(this.getU());
	
		return result;
	}

	@Override
	public UncertainReal power(float s) {
		UncertainRealNumber result = new UncertainRealNumber();
		
		double a = Math.pow(this.getX(), s);
		double b = ((s*(s-1))/2) * (Math.pow(this.getX(), s-2)) * (this.getU()*this.getU());
		result.setX(a + b);
		double c = s * this.getU() * (Math.pow(this.getX(), s-1));
		result.setU(c);
	
		return result;
	}

	@Override
	public UncertainReal sqrt() {
		UncertainRealNumber result = new UncertainRealNumber();
		
		double a = Math.sqrt(this.getX());
		double b = (this.getU()*this.getU()) / ((8)*Math.pow(this.getX(), 3/2));
		result.setX(a - b);
		double c = (this.getU()) / (2*Math.sqrt(this.getX()));
		result.setU(c);
	
		return result;
	}

	@Override
	public boolean lessThan(UncertainReal r) {
		boolean result = false;
		result = (this.getX() < r.getX()) &&
                 ((this.getX() + this.getU())  < (r.getX() - r.getU()));
		return result;
	}
	
	@Override
	public boolean lessEq(UncertainReal r) {
		boolean result = false;
		result = (this.lessThan(r) || this.equals(r));
		return result;
	}

	@Override
	public boolean gt(UncertainReal r) {
		boolean result = false;
		
		result = r.lessThan(this);
		
		return result;
	}
	
	@Override
	public boolean ge(UncertainReal r) {
		boolean result = false;
		
		result = (this.gt(r) || this.equals(r)); 
		
		return result;
	}
	

	public boolean equals(UncertainReal r) {
		boolean result = false;
		
		double a = Math.max((this.getX() - this.getU()), (r.getX() - r.getU()));
		double b = Math.min((this.getX() + this.getU()), (r.getX() + r.getU()));
		result = (a <= b);
		
		return result;
	}

	public boolean distinct(UncertainReal r) {
		boolean result = false;
		
		result =  ( !(this.equals(r)) );
		
		return result;
	}
	
	public UncertainReal inv() { //inverse (reciprocal)
		return new UncertainRealNumber(1.0,0.0).divide(this);
	}
	
	public UncertainReal floor() { //returns (i,u) with i the largest int such that (i,u)<=(x,u)
		return new UncertainRealNumber(Math.floor(this.getX()),this.getU());
	}
	public UncertainReal round(){ //returns (i,u) with i the closest int to x
		return new UncertainRealNumber(Math.round(this.getX()),this.getU());
	}
	public UncertainReal min(UncertainReal r) {
		if (r.lessThan(this)) return new UncertainRealNumber(r.getX(),r.getU()); 
		return new UncertainRealNumber(this.getX(),this.getU());
	}
	public UncertainReal max(UncertainReal r) {
		//if (r>this) r; else this;
		if (r.gt(this)) return new UncertainRealNumber(r.getX(),r.getU());
		return new UncertainRealNumber(this.getX(),this.getU());
	}

	/******
	 * Conversions
	 */
	
	public String toString() {
		return "(" + x + "," + u + ")";
	}
	
	
	public int toInteger(){ //
		return (int)Math.floor(this.getX());
	}
	
	public double toReal()  { 
		return this.getX();
	}
	
	/**
	 * Other Methods 
	 */

 	public int hashcode(){ //required for equals()
		return Math.round((float)x);
	}

 	public UncertainRealNumber clone() {
		return new UncertainRealNumber(this.getX(),this.getU());
	}

}
