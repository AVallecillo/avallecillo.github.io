
public interface UncertainReal {
	public double getX();
	public void setX(double d);
	public double getU();
	public void setU(double u);
	public UncertainReal add(UncertainReal r);
	public UncertainReal minus(UncertainReal r);
	public UncertainReal mult(UncertainReal r);
	public UncertainReal divide(UncertainReal r);
	public UncertainReal abs();
	public UncertainReal neg();
	public UncertainReal power(float s);
	public UncertainReal sqrt();
	public boolean lessThan(UncertainReal r);
	public boolean lessEq(UncertainReal r);
	public boolean gt(UncertainReal r);
	public boolean ge(UncertainReal r);
	public boolean equals(UncertainReal r);
	public boolean distinct (UncertainReal r);
	public int hashcode();
	public String toString();
	//added in version 2
	public UncertainReal inv(); //inverse (reciprocal)
	public UncertainReal floor(); //returns (i,u) with i the largest int such that (i,u)<=(x,u)
	public UncertainReal round(); //returns (i,u) with i the closest int to x
	public UncertainReal min(UncertainReal r); //if (r<this) r; else this;
	public UncertainReal max(UncertainReal r);//if (r>this) r; else this;
	public int toInteger(); //returns this.getX().toInteger()
	public double toReal(); //returns this.getX()
	//in addition, two constructors are added
	//public UncertainReal(String x); //creates an UncertainReal from a string representing a real, with u=0.
	//public UncertainReal(String x, String u); //creates an UncertainReal from two strings representing (x,u).
}
