
public interface IUReal {
	public double getX();
	public void setX(double d);
	public double getU();
	public void setU(double u);
	public IUReal add(IUReal r);
	public IUReal minus(IUReal r);
	public IUReal mult(IUReal r);
	public IUReal divideBy(IUReal r);
	public IUReal abs();
	public IUReal neg();
	public IUReal power(float s);
	public IUReal sqrt();
	public boolean lessThan(IUReal r);
	public boolean lessEq(IUReal r);
	public boolean gt(IUReal r);
	public boolean ge(IUReal r);
	public boolean equals(IUReal r);
	public boolean distinct (IUReal r);
	public int hashcode();
	public String toString();
	public IUReal inverse(); //inverse (reciprocal)
	public IUReal floor(); //returns (i,u) with i the largest int such that (i,u)<=(x,u)
	public IUReal round(); //returns (i,u) with i the closest int to x
	public IUReal min(IUReal r); //if (r<this) r; else this;
	public IUReal max(IUReal r);//if (r>this) r; else this;
	public int toInteger(); //returns this.getX().toInteger()
	public double toReal(); //returns this.getX()
	//in addition, two constructors are added
	//public IUReal(String x); //creates an IUReal from a string representing a real, with u=0.
	//public IUReal(String x, String u); //creates an IUReal from two strings representing (x,u).
}
