[FormatInfo]
Type=TeXnicCenterProjectSessionInformation
Version=1

[SessionInfo]
ActiveTab=0
FrameCount=1

[Frame0]
Columns=1
Rows=1
Flags=2
ShowCmd=3
MinPos.x=-1
MinPos.y=-1
MaxPos.x=-4
MaxPos.y=-24
NormalPos.left=0
NormalPos.top=0
NormalPos.right=1006
NormalPos.bottom=388
Class=CLatexEdit
Document=C:\Dokumente und Einstellungen\emac\Desktop\mdwe_paper\MDWE_Paper.tex

[Frame0_Row0]
cyCur=604
cyMin=10

[Frame0_Col0]
cxCur=1174
cxMin=10

[Frame0_View0,0]
Cursor.row=76
Cursor.column=25
TopSubLine=1128

