[FormatInfo]
Type=TeXnicCenterProjectSessionInformation
Version=1

[SessionInfo]
ActiveTab=0
FrameCount=3

[Frame0]
Columns=1
Rows=1
Flags=0
ShowCmd=1
MinPos.x=-1
MinPos.y=-1
MaxPos.x=-4
MaxPos.y=-24
NormalPos.left=69
NormalPos.top=69
NormalPos.right=959
NormalPos.bottom=483
Class=CLatexEdit
Document=acm_proc_article-sp.cls

[Frame0_Row0]
cyCur=366
cyMin=10

[Frame0_Col0]
cxCur=862
cxMin=10

[Frame0_View0,0]
Cursor.row=296
Cursor.column=0
TopSubLine=275

[Frame1]
Columns=1
Rows=1
Flags=0
ShowCmd=1
MinPos.x=-1
MinPos.y=-1
MaxPos.x=-4
MaxPos.y=-24
NormalPos.left=46
NormalPos.top=46
NormalPos.right=932
NormalPos.bottom=456
Class=CLatexEdit
Document=MDWE_Paper.tex

[Frame1_Row0]
cyCur=362
cyMin=10

[Frame1_Col0]
cxCur=858
cxMin=10

[Frame1_View0,0]
Cursor.row=0
Cursor.column=0
TopSubLine=0

[Frame2]
Columns=1
Rows=1
Flags=2
ShowCmd=3
MinPos.x=-1
MinPos.y=-1
MaxPos.x=-4
MaxPos.y=-24
NormalPos.left=92
NormalPos.top=92
NormalPos.right=982
NormalPos.bottom=506
Class=CLatexEdit
Document=sig-alternate.tex

[Frame2_Row0]
cyCur=578
cyMin=10

[Frame2_Col0]
cxCur=1054
cxMin=10

[Frame2_View0,0]
Cursor.row=994
Cursor.column=0
TopSubLine=994

